import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class VoidAnimation {
	private Timer timer;
	private int velocity1, x1, velocity2, xSave, ySave, y2, timeElapsed, totalTime;
	private JFrame frame;
	private JPanel panel, nxtPanel;
	
	public VoidAnimation(JFrame frame, JPanel panel, JPanel nxtPanel){
		this.frame=frame;
		this.panel=panel;
		this.nxtPanel=nxtPanel;
		try{
			this.xSave = panel.getX();
		}catch(NullPointerException e){
		}
	}
	
	public void animatePanel(final int animationTime, int delay){
		timer = new Timer();
		try{
			//System.out.println("#11.5= "+panel.getLocation()+" "+nxtPanel.getLocation()+" "+panel.isVisible()+" "+nxtPanel.isVisible());
			velocity1 = (frame.getWidth()-panel.getX())*100/animationTime;
			xSave=panel.getX();
			x1=panel.getX();
		}catch(NullPointerException e){
		}
		try{
			velocity2 = (frame.getHeight()-nxtPanel.getY())*100/animationTime;
			ySave= nxtPanel.getY();
		}catch(NullPointerException e){
		}
		y2=frame.getHeight();
		timeElapsed=0;
		
		timer.scheduleAtFixedRate(new TimerTask(){
			public void run() {
				x1+=velocity1;
				if(y2>ySave){
					y2-=velocity2;
				}
				timeElapsed+=100;
				try{
					nxtPanel.setVisible(true);
					nxtPanel.setLocation(nxtPanel.getX(), y2);
				}catch(NullPointerException e){
				}
				try{
					panel.setLocation(x1, panel.getY());
					//System.out.println("#11.6= "+panel.getLocation()+" "+nxtPanel.getLocation()+" "+panel.isVisible()+" "+nxtPanel.isVisible());
				}catch(NullPointerException e){
				}
				if(timeElapsed >= animationTime){
					try{
						panel.setVisible(false);
						panel.setLocation(xSave, ySave);
					}catch(NullPointerException e){
					}
					timer.cancel();
				}
			}
		}, delay, 100);

		
	}
	
	public void animateSideBar(int animationTime, int delay, final int direction){
		timer = new Timer();
		try{
			//System.out.println("#2.1= "+panel.getX());
			velocity1 = (xSave)*100/animationTime;
			//System.out.println("#6.9= "+velocity1 + " 7.0= "+xSave);
			if(direction==1){
				x1=0;
				this.totalTime=(xSave-x1)*100/velocity1;
				//System.out.println("#9.1= " +totalTime);
			}else{
				x1=panel.getX();
				this.totalTime=(x1)*100/velocity1;
				//System.out.println("#9.2= " +totalTime);
			}
		}catch(NullPointerException e){
		}
		timeElapsed=0;
		panel.setVisible(true);
		timer.scheduleAtFixedRate(new TimerTask(){
			public void run() {
				//System.out.println("#1.7");
				x1+=(direction*velocity1);
				//System.out.println("#1.8= "+x1+" #3.0= "+timeElapsed);
				try{
					panel.setLocation(x1, panel.getY());
				}catch(NullPointerException e){
				}
				timeElapsed+=100;
				if(timeElapsed >= totalTime){
					turnOffTimer();
					try{
						//System.out.println("#1.9= "+velocity1+" #2.0= "+panel.getX());
						if(x1<=0){
							panel.setVisible(false);
						}
					}catch(NullPointerException e){
					}
				}
			}
		}, delay, 100);
	}
	
	public void turnOffTimer(){
		try{
			timer.cancel();
		}catch(NullPointerException e){
		}
	}
}
