import java.awt.Color;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics;
import java.awt.Shape;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.geom.RoundRectangle2D;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class VoidPasswordField extends JPasswordField implements FocusListener{
	private Shape shape;
    private String hint;
    //private boolean showingHint;
    public VoidPasswordField(String hint, int size) {
        super(hint, size);
        //super();
        setOpaque(false); // As suggested by @AVD in comment.
        this.hint = hint;
        //this.showingHint = true;
        addFocusListener(this);
        try {
			Font f = Font.createFont(Font.TRUETYPE_FONT, ClassLoader.getSystemResourceAsStream("fonts/fon9.otf")).deriveFont(Font.PLAIN, 20);
			setFont(f);
        } catch (FontFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        setHorizontalAlignment(JTextField.CENTER);
        setForeground(Color.WHITE);
        setEchoChar((char) 0);
    }
	protected void paintComponent(Graphics g) {
        g.setColor(new Color(255, 0, 0));
        g.fillRoundRect(0, 0, getWidth()-1, getHeight()-1, 35, 35);
        super.paintComponent(g);
   }
   protected void paintBorder(Graphics g) {
        g.setColor(new Color(255, 255, 255, 0));
        g.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 50, 50);
   }
   public boolean contains(int x, int y) {
        if (shape == null || !shape.getBounds().equals(getBounds())) {
            shape = new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-1, 15, 15);
        }
        return shape.contains(x, y);
   }
@Override
public void focusGained(FocusEvent e) {
	// TODO Auto-generated method stub
	if(this.getText().equals(hint)) {
	      super.setText("");
	      //echoCharIsSet();
	      setEchoChar('*');
	}
}
@Override
public void focusLost(FocusEvent e) {
	// TODO Auto-generated method stub
	if(this.getText().isEmpty()) {
	      super.setText(hint);
	      setEchoChar((char) 0);
	}
}
}
