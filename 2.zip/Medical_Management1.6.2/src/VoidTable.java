import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontFormatException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.UIManager;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableRowSorter;


public class VoidTable extends JTable{
	private DefaultTableModel model;
	private TableColumn column;
	public VoidTable(){
		setOpaque(false);
		((DefaultTableCellRenderer)getTableHeader().getDefaultRenderer()).setHorizontalAlignment(JLabel.LEFT);
		model = (DefaultTableModel) getModel();
		setBackground(new Color(0, 0, 0, 0));
		setForeground(Color.white);
		getTableHeader().setBackground(Color.GRAY);
		getTableHeader().setForeground(Color.white);
		getTableHeader().setPreferredSize(new Dimension(100, 50));
		setShowVerticalLines(false);
		setGridColor(Color.WHITE);
		UIManager.getDefaults().put("TableHeader.cellBorder" , BorderFactory.createEmptyBorder(0,0,0,0));
		setRowHeight(100);
		setAutoCreateRowSorter(true);
		try {
			Font f = Font.createFont(Font.TRUETYPE_FONT, ClassLoader.getSystemResourceAsStream("fonts/fon9.otf")).deriveFont(Font.PLAIN, 12);
			setFont(f);
			f = Font.createFont(Font.TRUETYPE_FONT, ClassLoader.getSystemResourceAsStream("fonts/fon9.otf")).deriveFont(Font.PLAIN, 15);
			getTableHeader().setFont(f);
        } catch (FontFormatException | IOException e) {
			e.printStackTrace();
		}
		//getModel().addTableModelListener(this);
	}
	
	
	
	 public void hideColumn(int index) {
		    column = getColumnModel().getColumn(index);
		    column.setMinWidth(0);
		    column.setMaxWidth(0);
		    column.setWidth(0);
		    column.setPreferredWidth(0);
		    doLayout();
	 }
	 public void showColumn(int index) {
		    final int width = 250;
		    column.setMinWidth(15);
		    column.setMaxWidth(width);
		    column.setWidth(width);
		    column.setPreferredWidth(width);
		    doLayout();
	}
	 
	 public void tableSearch(final int columnIndex, final String text){
		 DefaultTableModel model = (DefaultTableModel) getModel();
			TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(model);
			RowFilter<Object, Object> filter = new RowFilter<Object, Object>() {
			      public boolean include(Entry entry) {
		    	      if (entry.getStringValue(columnIndex).toUpperCase().indexOf(text.toUpperCase())!=-1) {
		    	         return true;
		    	      }
			    	  return false;
			      }
			};
			sorter.setRowFilter(filter);
			setRowSorter(sorter);
	 }
	 
	 
}
