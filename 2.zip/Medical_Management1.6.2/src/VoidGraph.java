import java.awt.Color;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics;
import java.io.IOException;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.Locale;

import javax.swing.JLabel;
import javax.swing.JPanel;


public class VoidGraph extends JPanel{
	private JLabel yName[], xName[];
	private LinkedList<LinkedList<Object>> data;
	private Double yearlyIncome, maxIncome;
	private int lineWidth, day, month;
	private String monthS;
	private int graphYAxisSize;
	private Color[] color;
	private Calendar now;
	
	public VoidGraph(){
		now = Calendar.getInstance();
		day = now.get(Calendar.DAY_OF_MONTH);
		monthS = now.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault());
		month = now.get(Calendar.MONTH)+1;
		yName = new JLabel[12];
		xName = new JLabel[10];
		setLayout(null);
	}
	
	public void setXYaxis(LinkedList<LinkedList<Object>> data){
		color = new Color[12];
		color[0] = new Color(226,80,65);
		color[1] = new Color(155, 89, 182);
		color[2] = new Color(251,160,38);
		color[3] = new Color(149, 165, 166);
		color[4] = new Color(192, 57, 43);
		color[5] = new Color(241, 196, 15);
		color[6] = new Color(26, 188, 156);
		color[7] = new Color(236, 240, 241);
		color[8] = new Color(142, 68, 173);
		color[9] = new Color(39, 174, 96);
		color[10] = new Color(41, 128, 185);
		color[11] = new Color(84,172,210);
		this.data=data;
		yearlyIncome=0.0;
		maxIncome=0.0;
		lineWidth=getWidth()-280;
		for(int i=0; i<12; i++){
			yName[i] = new VoidLabel(data.get(i).get(0).toString()+",16", 25, Color.WHITE, new Color(0,0,0,0));
			add(yName[i]);
			yName[i].setBounds(80, 10+(i*43), 150, 30);
			Double thisMonthIncome= Double.valueOf((String) data.get(i).get(1));
			yearlyIncome+=thisMonthIncome;
			if(thisMonthIncome>maxIncome){
				maxIncome=thisMonthIncome;
			}
		}
		graphYAxisSize=(int) (maxIncome/5000)+1;
		for(int i=0; i<graphYAxisSize; i++){
			xName[i] = new VoidLabel(Integer.toString(5000*(i+1)), 15, Color.WHITE, new Color(0,0,0,0));
			add(xName[i]);
			xName[i].setBounds(210+((i+1)*(lineWidth/3)), getHeight()-40, 150, 30);
		}
	}
	
	public int getThisMonthIncome(){
		return (Double.valueOf((String) data.get(month-1).get(1)).intValue());
	}
	
	public int getGraphWidth(int row){
		return (Double.valueOf((String) data.get(row).get(1)).intValue())*lineWidth/(5000*graphYAxisSize);
	}
	
	protected void paintComponent(Graphics g){
        super.paintComponent(g);
		lineWidth=getWidth()-280;
        g.setColor(new Color(55, 55, 55));
        g.fillRect(0, 0, getWidth(), getHeight());
        for(int i=0; i<12; i++){
            g.setColor(color[i]);
            g.fillRoundRect(210, 10+(i*43), getGraphWidth(i), 23, 15, 15);
        }
        g.setColor(Color.WHITE);
        g.fillRect(210, getHeight()-45, lineWidth+50, 2);
	}
}
