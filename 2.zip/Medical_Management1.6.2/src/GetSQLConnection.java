import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;


public class GetSQLConnection {
	private Connection con;
	private Statement st;
	private ResultSet rs, rsMonth, rsUserInfo;
	private ResultSetMetaData rsmd;
	private LinkedList<LinkedList<Object>> allDataList, allMonthDataList;
	private LinkedList<String> allColumnNamesList;
	private boolean connected;
	
	public boolean setConnection(String user, String password){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "thevoid");
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM medicineStore");
			rsUserInfo = st.executeQuery("SELECT * FROM userInfo");
			rsmd = rs.getMetaData();
			while(rsUserInfo.next()){
				System.out.println(rsUserInfo.getString(1) + " " + rsUserInfo.getString(2) + " " + rsUserInfo.getString(3));
				if(rsUserInfo.getString(2).equals(user) && rsUserInfo.getString(3).equals(password)){
					connected = true;
					return true;
				}
			}
			connected = false;
			return false;
		}catch(Exception e){
			System.out.println(e);
			connected = false;
			return false;
		}
	}
	
	public boolean isConnected(){
		return connected;
	}
	
	public String getRow(int row){
		try {
			rs = st.executeQuery("SELECT * FROM medicineStore");
			for(int i=0; i<row; i++){
				rs.next();
			}
			return rs.getString(1)+ "\t"+rs.getString(2)+ "\t"+rs.getString(3)+ "\t"+rs.getString(4)+"\t"+rs.getString(5)+ "\t"+rs.getString(6)+ "\t"+rs.getString(7);
		} catch (SQLException e) {
			System.out.println(e);
			return "Error in getRow()";
		}
	}
	
	public Object[][] getAllTableData(){
		try {
			int rowSize = getRowSize(), columnSize = getColumnSize();
			Object[][] allData = new Object[rowSize][columnSize];
			allDataList = new LinkedList<LinkedList<Object>>();
			rs = st.executeQuery("SELECT * FROM medicineStore");
			for(int i=1; rs.next(); i++){
				allDataList.add(new LinkedList<Object>());
				for(int j=1; j<=columnSize; j++){
					allData[i-1][j-1]=rs.getString(j);
					allDataList.get(i-1).add(rs.getString(j));
				}
			}
			refreshMonthData();
			return allData;
			
		} catch (SQLException e) {
			System.out.println(e);
			return null;
		}
	}
	
	public LinkedList<LinkedList<Object>> refreshMonthData(){
		try {
			allMonthDataList = new LinkedList<LinkedList<Object>>();
			rsMonth = st.executeQuery("SELECT * FROM medicineMonth");
			for(int i=1; rsMonth.next(); i++){
				allMonthDataList.add(new LinkedList<Object>());
				for(int j=1; j<=2; j++){
					allMonthDataList.get(i-1).add(rsMonth.getString(j));
				}
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
		return allMonthDataList;
	}
	
	public String getSelectedData(int column, int row){
		try {
			rs = st.executeQuery("SELECT * FROM medicineStore");
			for(int i=0; i<row; i++){
				rs.next();
			}
			return rs.getString(column);
		} catch (SQLException e) {
			System.out.println(e);
			return "Error in getSelectedData()";
		}
	}
	
	public int getColumnSize(){
		try {
			rsmd = st.executeQuery("SELECT * FROM medicineStore").getMetaData();
			return rsmd.getColumnCount();
		} catch (SQLException e) {
			System.out.println(e);
			return -1;
		}
	}
	
	public int getRowSize(){
		try {
			int size=0;
			rs = st.executeQuery("SELECT * FROM medicineStore");
			while(rs.next()){
				size++;
			}
			return size;
		} catch (SQLException e) {
			System.out.println(e);
			return -1;
		}
	}
	
	public void insertDataInTable(Object data){
		LinkedList<Object> list = new LinkedList<Object>();
		int column = getColumnSize();
		for(int i=0; i<column; i++){
			list.add(null);
		}
		list.set(0, data);
		allDataList.add(list);
	}
	
	public void updateDataInTable(Object data, int rowIndex, int columnIndex){
		allDataList.get(rowIndex).set(columnIndex, data);
	}
	
	public void deleteDataFromTable(int rowIndex){
		allDataList.remove(rowIndex);
	}
	
	public String[] getAllColumnNames(){
		try {
			int columnSize = getColumnSize();
			rs = st.executeQuery("select COLUMN_NAME from ALL_TAB_COLUMNS where TABLE_NAME = 'MEDICINESTORE'");
			String[] allColumnNames = new String[columnSize];
			allColumnNamesList = new LinkedList<String>();
			for(int i=1; rs.next(); i++){
				allColumnNames[columnSize-i]=rs.getString(1);
				allColumnNamesList.add(0, rs.getString(1));
			}
			return allColumnNames;
		} catch (SQLException e) {
			System.out.println(e);
			return null;
		}
	}
	
	public boolean setSignUp(String userName, String password){
		try {
			while(rsUserInfo.next()){
				rsUserInfo = st.executeQuery("SELECT * FROM userInfo");
				if(rsUserInfo.getString(2).equals(userName)){
					return false;
				}
			}
			st.executeUpdate("INSERT INTO medicineStore(ID, userName, password) VALUES(seq_username, '" + userName + "', '"+ password +"')");
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public void saveAllDataInTable(){
		try {
			st.execute("truncate table medicineStore");
			for(int i=0; i<allDataList.size(); i++){
				if(allDataList.get(i).get(0)!=null){
					st.executeUpdate("INSERT INTO medicineStore(" + allColumnNamesList.get(0).toString() + ") VALUES('" + allDataList.get(i).get(0).toString() + "')");
				}
				for(int j=1; j<allColumnNamesList.size(); j++){
					if(allDataList.get(i).get(j)!=null){
						st.executeUpdate("UPDATE medicineStore SET " + allColumnNamesList.get(j) + " = '" + allDataList.get(i).get(j).toString() + "' where " + allColumnNamesList.get(0) + " = '" + allDataList.get(i).get(0).toString() + "'");
					}
				}
			}
		} catch (SQLException e) {
		}
	}
	
	public void closeConnection(){
		try {
			con.close();
			connected = false;
		} catch (SQLException e) {
			System.out.println(e);
		}
	}
}
