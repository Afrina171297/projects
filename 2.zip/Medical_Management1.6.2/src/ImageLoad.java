import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JComponent;

public class ImageLoad extends JComponent{
	private Image image;
	public ImageLoad(String string, int width, int height) {
		try {
			//image = ImageIO.read(new File(getClass().getClassLoader().getResource(string).getFile()));
			image = ImageIO.read(ClassLoader.getSystemResource(string));
			resizeImage(width, height);
			setOpaque(false);
		} catch (IOException e) {
			System.out.println(e);
		}
	}
	public ImageLoad() {
		// TODO Auto-generated constructor stub
	}
	protected void paintComponent(Graphics g){
		super.paintComponent(g);
		g.drawImage(image, 0, 0, this);
	}
	
	public void resizeImage(int width, int height){
		image = image.getScaledInstance(width, height, Image.SCALE_DEFAULT);
	}
	
	public int getHeight(){
		return image.getHeight(this);
	}
	
	public int getWidth(){
		return image.getWidth(this);
	}
}
