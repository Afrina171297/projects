import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Arc2D;
import java.util.LinkedList;

import javax.swing.JLabel;
import javax.swing.JPanel;


public class VoidPieChart extends JPanel{
	private JLabel name[];
	private Color color[];
	private LinkedList<LinkedList<Object>> data;
	private Double yearlyIncome;
	
	public VoidPieChart(){
		color = new Color[12];
		name = new JLabel[12];
		color[0] = new Color(226,80,65);
		color[1] = new Color(155, 89, 182);
		color[2] = new Color(251,160,38);
		color[3] = new Color(149, 165, 166);
		color[4] = new Color(192, 57, 43);
		color[5] = new Color(241, 196, 15);
		color[6] = new Color(26, 188, 156);
		color[7] = new Color(236, 240, 241);
		color[8] = new Color(142, 68, 173);
		color[9] = new Color(39, 174, 96);
		color[10] = new Color(41, 128, 185);
		color[11] = new Color(84,172,210);
		setLayout(null);
	}
	
	public void setPieChart(LinkedList<LinkedList<Object>> data){
		this.data = data;
		yearlyIncome = 0.0;
		for(int i=0; i<12; i++){
			name[i] = new VoidLabel(data.get(i).get(0).toString()+",16", 25, Color.WHITE, new Color(0,0,0,0));
			add(name[i]);
			name[i].setBounds(800, 10+(i*43), 150, 30);
			Double thisMonthIncome= Double.valueOf((String) data.get(i).get(1));
			yearlyIncome+=thisMonthIncome;
		}
		
	}
	
	
	public int getPieChartWidth(int row){
		return (int) ((Double.valueOf((String) data.get(row).get(1)).intValue())*360/(yearlyIncome));
	}
	
	
	protected void paintComponent (Graphics g) {
	    Graphics2D g2 = (Graphics2D) g;
	    g2.setStroke(new BasicStroke(50, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL));
	    int start = 90;
	    
	    
	    for(int i=0; i<12; i++){
		    g2.setPaint(color[i]);
		    g2.draw(new Arc2D.Double(150, 50, 400, 400, start+2, getPieChartWidth(i)-4, Arc2D.OPEN));
		    start+=getPieChartWidth(i);
		    g.fillRoundRect(750, 7+(i*43), 30, 30, 15, 15);
	    }
	}
}
