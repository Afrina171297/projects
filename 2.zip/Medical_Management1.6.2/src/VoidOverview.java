import java.awt.Color;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics;
import java.io.IOException;
import java.util.Calendar;
import java.util.Locale;

import javax.swing.JPanel;


public class VoidOverview extends JPanel{
	private Calendar now;
	private int month, day, thisMonthIncome, thisMonthSale;
	private String monthS;
	public VoidOverview(){
		now = Calendar.getInstance();
		day = now.get(Calendar.DAY_OF_MONTH);
		monthS = now.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault());
		month = now.get(Calendar.MONTH)+1;
		System.out.println(day + " " + month + " " + monthS);
	}
	
	public void setData(int thisMonthIncome, int thisMonthSale){
		this.thisMonthIncome = thisMonthIncome;
		this.thisMonthSale = thisMonthSale;
	}
	
	protected void paintComponent(Graphics g){
        super.paintComponent(g);
        //Text Font
        Font f = null;
		try {
			f = Font.createFont(Font.TRUETYPE_FONT, ClassLoader.getSystemResourceAsStream("fonts/fon9.otf")).deriveFont(Font.PLAIN, 30);
		} catch (FontFormatException e) {
		} catch (IOException e) {
		}
        //Background
        g.setColor(new Color(55, 55, 55));
        g.fillRect(0, 0, getWidth(), getHeight());
        //White Line
        g.setColor(Color.WHITE);
        g.fillRect(25, 0, 1100, 2);
        //Red Box
        g.setColor(new Color(226,80,65));
        g.fillRect(25, 30, 700, 300);
        g.setColor(new Color(192, 57, 43));
        g.fillRect(25, 30, 700, 50);
        
        //Purple Box
        g.setColor(new Color(155, 89, 182));
        g.fillRect(740, 30, 345, 300);
        g.setColor(new Color(142, 68, 173));
        g.fillRect(740, 30, 345, 50);
        
        //Yellow Box
        g.setColor(new Color(241, 196, 15));
        g.fillRect(25, 345, 1100, 205);
        g.setColor(new Color(251,160,38));
        g.fillRect(25, 345, 1100, 50);
        
    	g.setFont(f);
        g.setColor(Color.WHITE);
        g.drawString("This Month", 50, 65);
        g.drawString("This Year", 760, 65);
        g.drawString("Products", 50, 380);
        
        g.setFont(f.deriveFont(Font.PLAIN, 100));
        g.drawString(String.valueOf(day), 100, 200);
        g.drawString(String.valueOf(month), 810, 200);
        g.drawString(String.valueOf(thisMonthSale), 100, 450);
        
        
        g.setFont(f.deriveFont(Font.PLAIN, 20));
        g.drawString(monthS, 80, 250);
        
        
	}

}
