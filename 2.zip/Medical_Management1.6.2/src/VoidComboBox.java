import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.DefaultListCellRenderer;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.JComponent;


public class VoidComboBox extends JComboBox{
	public VoidComboBox(int fontSize){
		
		//UIManager.put("ComboBox.background", new ColorUIResource(UIManager.getColor("TextField.background")));
		//UIManager.put("ComboBox.foreground", new ColorUIResource(UIManager.getColor("TextField.foreground")));
		//setBorder(BorderFactory.createEmptyBorder());
		//setUI(new javax.swing.plaf.basic.BasicComboBoxUI());
        setBackground(new Color(55, 55, 55));
		UIManager.put("ComboBox.selectionBackground", new ColorUIResource(new Color(55, 55, 55)));
		setForeground(Color.WHITE);
		UIManager.put("ComboBox.selectionForeground", new ColorUIResource(Color.WHITE));
		setRenderer(new ComboBoxListCellRenderer());
		try {
			Font f = Font.createFont(Font.TRUETYPE_FONT, ClassLoader.getSystemResourceAsStream("fonts/fon9.otf")).deriveFont(Font.PLAIN, fontSize);
			this.setFont(f);
        } catch (FontFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//UIManager.put("ComboBox.borderPaintsFocus", Boolean.FALSE);
		/*for (int i=0; i<getComponentCount(); i++)
		{
			if (getComponent(i) instanceof AbstractButton)
			{
				((AbstractButton)getComponent(i)).setBorderPainted(false);
			}
		}*/
        setUI(new BasicComboBoxUI()
        {
            @Override
            public void paint(final Graphics g, final JComponent c)
            {

                final Rectangle r = this.rectangleForCurrentValue();
                this.paintCurrentValueBackground(g, r, true);
                this.paintCurrentValue(g, r, true);

            }

            @Override
            public void paintCurrentValueBackground(final Graphics g, final Rectangle bounds, final boolean hasFocus)
            {
                //final Color t = g.getColor();
                final Color t = new Color(0, 0, 0, 0);
            	if (this.comboBox.isEnabled())
                    g.setColor(new Color(0,0,0,0));
                g.fillRect(bounds.x, bounds.y, bounds.width, bounds.height);
                g.setColor(t);
            }

            @Override
            protected JButton createArrowButton()
            {
            	JButton arrow = new JButton();
            	try {
            	    Image img = ImageIO.read(ClassLoader.getSystemResource("icons/icon12.png"));
            		img = img.getScaledInstance(19, 12, Image.SCALE_DEFAULT);
            		arrow.setBackground(new Color(55, 55, 55));
            		arrow.setBorder(BorderFactory.createEmptyBorder(0,0,0,0));
            	    arrow.setIcon(new ImageIcon(img));
            	  } catch (IOException ex) {
            		  
            	  }
            	return arrow;
            }
        });


	}
	
	public static class ComboBoxListCellRenderer extends DefaultListCellRenderer
    {
        /**
         * 
         */
        //private static final long serialVersionUID = 1L;

        @Override
        public Component getListCellRendererComponent(final JList list, final Object value, final int index, final boolean isSelected, final boolean cellHasFocus)
        {
            if (isSelected)
            {
                this.setBackground(Color.RED);
                this.setForeground(Color.WHITE);
            }
            else
            {
                this.setBackground(Color.WHITE);
                this.setForeground(Color.BLACK);
            }

            this.setText((String) value);
            this.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            try {
    			Font f = Font.createFont(Font.TRUETYPE_FONT, ClassLoader.getSystemResourceAsStream("fonts/fon9.otf")).deriveFont(Font.PLAIN, 13);
    			this.setFont(f);
            } catch (FontFormatException | IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
            return this;
        }
    }

}
