import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.JScrollPane;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;


public class VoidScrollPane extends JScrollPane{
	
	public VoidScrollPane(){
		setOpaque(false);
		getViewport().setOpaque(false);
		setBorder(BorderFactory.createEmptyBorder());
//UIManager.put("ScrollBar.thumbHighlight", new ColorUIResource(Color.ORANGE));
		//UIManager.put("ScrollBar.thumb", new ColorUIResource(33,129,176));
	}
	
}
