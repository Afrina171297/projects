import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.plaf.ColorUIResource;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableRowSorter;


public class MainDesignPage {

	private JFrame frame;
	private JPanel panelStartPage, panelStartSelect, panelJoin[], panelMenu[], panelSideBar[];
	private VoidGraph graphBox;
	private VoidOverview overviewBox;
	private JLabel lblAppName, lblAppName2, lblLogIn, lblSignUp, joinPagelbl[], lblWarning[], lblTableDates, lblTableAmounts, lblTableDetails, lblPanel[];
	private ImageLoad appLogo, logInLogo, signUpLogo, joinPageLogo[], sideBarLogo[];
	private JTextField txtUserName[], txtSearch;
	private JPasswordField passwordLogIn[];
	private int timeElapsed, x1, y2, velocity1, velocity2, ySave, currentPanel, currentPanelMenu2;
	private Timer timer;
	private GetSQLConnection conA;
	private VoidTable table;
	private DefaultTableModel model;
	private JScrollPane scrollPane;
	private JComboBox comboBox[];
	private String joinPageLogoAddress[]={"icons/icon3.png", "icons/login.png"};
	private String lblPanelButtonText[] = {"Login", "Sign Up"};
	private String sideBarLogoAddress[]={"icons/icon9.png", "icons/icon7.png", "icons/icon5.png", "icons/icon13.png", "icons/icon11.png", "icons/icon4.png", "icons/icon10.png"};
	private String lblPanelText[] = {"Overview", "All Records"};
	private VoidAnimation animate[];
	private JPanel[] panelGraph;
	private VoidPieChart pieChartBox;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainDesignPage window = new MainDesignPage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainDesignPage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("Medical Management");
		frame.setBounds(0, 0, 1280, 720);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
            	Object[] options = {"Save & Quit", "Don't Save", "Cancel"};
            	int choose = JOptionPane.showOptionDialog(null, "Do you want to save and quit?", "Confirm!", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[2]);
            	if (choose == JOptionPane.YES_OPTION) {
            		conA.saveAllDataInTable();
            		conA.closeConnection();
                    e.getWindow().dispose();
                }else if (choose == JOptionPane.NO_OPTION) {
                	try{
	            		conA.closeConnection();
                	}catch(Exception e1){
                		System.out.println(e1);
                	}
                    e.getWindow().dispose();
                }else{
                }
            }
        });
		frame.getContentPane().setLayout(null);
		frame.getContentPane().setBackground(new Color(55, 55, 55));
		frame.addComponentListener(new ComponentListener(){
			public void componentResized(ComponentEvent e) {
	            Dimension newSize = e.getComponent().getBounds().getSize();
	            panelStartPage.setLocation(150, 200);
	            for(int i=0; i<2; i++){
					panelJoin[i].setBounds(400, 100, 550, 550);
		    		txtUserName[i].setBounds(0, 250, 500, 60);
		    		passwordLogIn[i].setBounds(0, 330, 500, 60);
					joinPagelbl[i].setLocation(170, 370);
					joinPageLogo[i].setLocation(150, 0);
					lblWarning[i].setLocation(120,310);
	            }
				for(int i=0; i<3; i++){
					panelMenu[i].setBounds(0, 0, newSize.width, newSize.height);
				}
				panelStartSelect.setLocation(300, 250);
				panelSideBar[0].setBounds(0, 0, 150, newSize.height);
				panelSideBar[1].setBounds(150, 110, 85, 350);
				lblAppName.setLocation(0, 80);
				lblAppName2.setLocation(490, 125);
				lblLogIn.setLocation(20,140);
				for(int i=0; i<2; i++){
					lblPanel[i].setLocation(180,0);
				}
				lblSignUp.setLocation(400, 140);
				appLogo.setLocation(0, 0);
				logInLogo.setLocation(0, 0);
				for(int i=0; i<4; i++){
					sideBarLogo[i].setLocation(20, 90+i*130);
				}
				for(int i=4; i<7; i++){
					sideBarLogo[i].setLocation(15, 30+((i%4)*100));
				}
				signUpLogo.setLocation(400, 0);
	    		txtSearch.setBounds(newSize.width-300, 50, 250, 40);
				scrollPane.setBounds(160, 150, newSize.width-170, newSize.height-150);
				comboBox[0].setBounds(newSize.width-250, 100, 170, 20);
				comboBox[1].setBounds(180, 70, 300, 50);
			}
			public void componentMoved(ComponentEvent e) {
			}
			public void componentShown(ComponentEvent e) {
			}
			public void componentHidden(ComponentEvent e) {
			}
		});
		
		
		
		
		panelStartPage = new JPanel();
		panelStartPage.setSize(1000, 250);
		panelStartPage.setOpaque(false);
		panelStartPage.setBackground(new Color(0, 0, 0));
		frame.getContentPane().add(panelStartPage);
		panelStartPage.setLayout(null);
		panelStartPage.setVisible(true);
        panelStartPage.setLocation(150, 200);
		
		lblAppName = new VoidLabel("Medical Management", 80, Color.WHITE, new Color(0,0,0,0));
		lblAppName.setBounds(30, 156, 1200, 200);
		panelStartPage.add(lblAppName);
		
		lblAppName2 = new VoidLabel("Your Health's Companion", 30, Color.WHITE, new Color(0,0,0,0));
		lblAppName2.setBounds(30, 156, 1200, 200);
		panelStartPage.add(lblAppName2);
		
		appLogo = new ImageLoad("icons/heart2.png", 248, 144);
		appLogo.setSize(500, 500);
		panelStartPage.add(appLogo);
		
		panelStartSelect = new JPanel();
		panelStartSelect.setSize(650, 300);
		panelStartSelect.setOpaque(false);
		panelStartSelect.setBackground(new Color(0, 0, 0, 0));
		frame.getContentPane().add(panelStartSelect);
		panelStartSelect.setLayout(null);
		panelStartSelect.setVisible(false);
		panelStartSelect.setLocation(300, 250);
		
		logInLogo = new ImageLoad("icons/icon3.png", 192, 192);
		logInLogo.setSize(200, 250);
		panelStartSelect.add(logInLogo);
		
		
		signUpLogo = new ImageLoad("icons/signup.png", 207, 189);
		signUpLogo.setSize(200, 250);
		panelStartSelect.add(signUpLogo);
		
		lblLogIn = new VoidLabel("LogIn", 50, Color.WHITE, new Color(0,0,0,0));
		lblLogIn.setBounds(30, 156, 200, 200);
		panelStartSelect.add(lblLogIn);
		
		lblSignUp = new VoidLabel("Sign Up", 50, Color.WHITE, new Color(0,0,0,0));
		lblSignUp.setBounds(30, 156, 1200, 200);
		panelStartSelect.add(lblSignUp);
		
		panelJoin = new JPanel[2];
		for(int i=0; i<2; i++){
			panelJoin[i] = new JPanel();
			panelJoin[i].setBounds(400, 100, 550, 550);
			panelJoin[i].setOpaque(false);
			panelJoin[i].setBackground(new Color(0, 0, 0, 0));
			frame.getContentPane().add(panelJoin[i]);
			panelJoin[i].setLayout(null);
			panelJoin[i].setVisible(false);
		}
		
		txtUserName = new JTextField[2];
		passwordLogIn = new JPasswordField[2];
		joinPageLogo = new ImageLoad[2];
		joinPagelbl = new JLabel[2];
		lblWarning = new JLabel[2];
		for(int i=0; i<2; i++){
			txtUserName[i] = new VoidTextField("User Name", 15, 20);
			panelJoin[i].add(txtUserName[i]);
			passwordLogIn[i] = new VoidPasswordField("Password", 15);
			panelJoin[i].add(passwordLogIn[i]);
			joinPageLogo[i] = new ImageLoad(joinPageLogoAddress[i], 192, 192);
			joinPageLogo[i].setSize(200, 250);
			panelJoin[i].add(joinPageLogo[i]);
			joinPagelbl[i] = new VoidLabel(lblPanelButtonText[i], 50, Color.WHITE, new Color(0,0,0,0));
			joinPagelbl[i].setBounds(30, 156, 200, 200);
			panelJoin[i].add(joinPagelbl[i]);
			lblWarning[i] = new VoidLabel("", 15, Color.WHITE, new Color(0,0,0,0));
			lblWarning[i].setBounds(30, 15, 300, 200);
			panelJoin[i].add(lblWarning[i]);
		}
		
		
		
		panelSideBar = new JPanel[2];
		for(int i=0; i<2; i++){
			panelSideBar[i] = new JPanel();
			frame.getContentPane().add(panelSideBar[i]);
			panelSideBar[i].setLayout(null);
			panelSideBar[i].setVisible(false);
		}
		panelSideBar[0].setBackground(new Color(80, 80, 80));
		panelSideBar[1].setBackground(new Color(0, 0, 0, 0));
		panelSideBar[0].setBounds(0, 200, 150, 720);
		panelSideBar[1].setBounds(150, 110, 85, 350);
		
		panelMenu = new JPanel[3];
		for(int i=0; i<3; i++){
			panelMenu[i] = new JPanel();
			panelMenu[i].setBounds(0, 0, 1280, 720);
			panelMenu[i].setOpaque(false);
			panelMenu[i].setBackground(new Color(0, 0, 0, 0));
			frame.getContentPane().add(panelMenu[i]);
			panelMenu[i].setLayout(null);
			panelMenu[i].setVisible(false);
		}
		
		panelGraph = new JPanel[3];
		for(int i=0; i<3; i++){
			panelGraph[i] = new JPanel();
			panelGraph[i].setBounds(160, 120, 1080, 560);
			panelGraph[i].setLayout(null);
			panelGraph[i].setBackground(new Color(55, 55, 55));
			panelMenu[2].add(panelGraph[i]);
		}
		
		graphBox = new VoidGraph();
		graphBox.setBounds(0, 0, 1080, 560);
		panelGraph[0].add(graphBox);
		
		pieChartBox = new VoidPieChart();
		pieChartBox.setBounds(0, 0, 1080, 560);
		panelGraph[1].add(pieChartBox);
		
		lblPanel = new JLabel[2];
		for(int i=0; i<2; i++){
			lblPanel[i] = new VoidLabel(lblPanelText[i], 45, Color.WHITE, new Color(0,0,0,0));
			lblPanel[i].setBounds(30, 15, 300, 200);
			panelMenu[i].add(lblPanel[i]);
		}
		
		scrollPane = new VoidScrollPane();
		panelMenu[1].add(scrollPane);
		
		
		comboBox = new JComboBox[2];
		comboBox[0] = new VoidComboBox(16);
		comboBox[1] = new VoidComboBox(45);
		for(int i=0; i<2; i++){
			panelMenu[i+1].add(comboBox[i]);
		}
		comboBox[0].setBounds(500, 300, 130, 20);
		comboBox[1].setBounds(30, 15, 300, 200);
		comboBox[1].setModel(new DefaultComboBoxModel(new String[]{"Graph", "Pie Chart"}));
		
		
		txtSearch = new VoidTextField("Search", 15, 15);
		panelMenu[1].add(txtSearch);
		
		animate = new VoidAnimation[12];
		animate[0]= new VoidAnimation(frame, panelStartPage, panelStartSelect);
		animate[0].animatePanel(500, 3*1000);
		
		
		sideBarLogo = new ImageLoad[7];
		for(int i=0; i<4; i++){
			sideBarLogo[i] = new ImageLoad(sideBarLogoAddress[i], 90, 90);
			sideBarLogo[i].setSize(90, 90);
			panelSideBar[0].add(sideBarLogo[i]);
		}
		
		for(int i=4; i<7; i++){
			sideBarLogo[i] = new ImageLoad(sideBarLogoAddress[i], 60, 60);
			sideBarLogo[i].setSize(50, 50);
			panelSideBar[1].add(sideBarLogo[i]);
		}
		
		overviewBox = new VoidOverview();
		overviewBox.setBounds(160, 120, 1080, 560);
		panelMenu[0].add(overviewBox);
		
		table = new VoidTable();
		
		currentPanelMenu2 = 0;
		comboBox[1].addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if(currentPanelMenu2!=comboBox[1].getSelectedIndex()){
					animate[8]= new VoidAnimation(frame, panelGraph[currentPanelMenu2], panelGraph[comboBox[1].getSelectedIndex()]);
					animate[8].animatePanel(700, 100);
					currentPanelMenu2 = comboBox[1].getSelectedIndex();
				}
			}
		});
		
		sideBarLogo[0].addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent e) {
				if(currentPanel!=0){
					animate[11]= new VoidAnimation(frame, panelMenu[currentPanel], panelMenu[0]);
					animate[11].animatePanel(1000, 100);
					currentPanel=0;
					System.out.println("#8.1");
				}
			}
			public void mousePressed(MouseEvent e) {
			}
			public void mouseReleased(MouseEvent e) {
			}
			public void mouseEntered(MouseEvent e) {
			}
			public void mouseExited(MouseEvent e) {
			}
		});
		
		
		animate[6]= new VoidAnimation(frame, panelSideBar[1], null);
		sideBarLogo[1].addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent e) {
				if(currentPanel!=1){
					animate[7]= new VoidAnimation(frame, panelMenu[currentPanel], panelMenu[1]);
					animate[7].animatePanel(1000, 100);
					currentPanel=1;
				}
			}
			public void mousePressed(MouseEvent e) {
			}
			public void mouseReleased(MouseEvent e) {
			}
			public void mouseEntered(MouseEvent e) {
				animate[6].turnOffTimer();
				animate[6].animateSideBar(600, 100, 1);
			}
			public void mouseExited(MouseEvent e) {
			}
		});
		
		sideBarLogo[2].addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent e) {
				if(currentPanel!=2){
					animate[4]= new VoidAnimation(frame, panelMenu[currentPanel], panelMenu[2]);
					animate[4].animatePanel(1000, 100);
					currentPanel=2;
				}
			}
			public void mousePressed(MouseEvent e) {
			}
			public void mouseReleased(MouseEvent e) {
			}
			public void mouseEntered(MouseEvent e) {
			}
			public void mouseExited(MouseEvent e) {
			}
		});
		
		sideBarLogo[3].addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent e) {
            	Object[] options = {"Yes, please", "No, thanks"};
				int choose = JOptionPane.showOptionDialog(null, "Do you want to logout?", "Confirm!", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[1]);
				if(choose==JOptionPane.YES_OPTION){
					animate[9]= new VoidAnimation(frame, panelMenu[currentPanel], panelStartSelect);
					animate[9].animatePanel(700, 100);
					animate[10]= new VoidAnimation(frame, panelSideBar[0], null);
					animate[10].animatePanel(700, 100);
				}
			}
			public void mousePressed(MouseEvent e) {
			}
			public void mouseReleased(MouseEvent e) {
			}
			public void mouseEntered(MouseEvent e) {
			}
			public void mouseExited(MouseEvent e) {
			}
		});
		
		sideBarLogo[4].addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				int nextValue;
				if(table.getRowCount()!=0){
					nextValue = Integer.valueOf((String) table.getValueAt(table.getRowCount()-1, 0));
				}else{
					nextValue = 0;
				}
				String nextValueInString = Integer.toString(nextValue+1);
				model.addRow(new Object[]{nextValueInString});
				conA.insertDataInTable(nextValueInString);
			}
			public void mousePressed(MouseEvent e) {
			}
			public void mouseReleased(MouseEvent e) {
			}
			public void mouseEntered(MouseEvent e) {
			}
			public void mouseExited(MouseEvent e) {
			}
		});
		
		sideBarLogo[5].addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent e) {
				conA.saveAllDataInTable();
			}
			public void mousePressed(MouseEvent e) {
			}
			public void mouseReleased(MouseEvent e) {
			}
			public void mouseEntered(MouseEvent e) {
			}
			public void mouseExited(MouseEvent e) {
			}
		});
		
		sideBarLogo[6].addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				int selectedRows[] = table.getSelectedRows();
				for(int i=0; i<selectedRows.length; i++){
					conA.deleteDataFromTable(selectedRows[selectedRows.length-i-1]);
					model.removeRow(selectedRows[selectedRows.length-i-1]);
				}
			}
			public void mousePressed(MouseEvent e) {
			}
			public void mouseReleased(MouseEvent e) {
			}
			public void mouseEntered(MouseEvent e) {
			}
			public void mouseExited(MouseEvent e) {
				System.out.println("#10.6");
			}
		});
		
		panelSideBar[1].addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent e) {
			}
			public void mousePressed(MouseEvent e) {
			}
			public void mouseReleased(MouseEvent e) {
			}
			public void mouseEntered(MouseEvent e) {
			}
			public void mouseExited(MouseEvent e) {
				Rectangle r = new Rectangle(0, 0, panelSideBar[1].getWidth(), panelSideBar[1].getHeight());
				if(!r.contains(e.getPoint())){
					animate[6].turnOffTimer();
					animate[6].animateSideBar(600, 100, -1);
				}
			}
		});
		
		passwordLogIn[0].addKeyListener(new KeyListener(){
			public void keyTyped(KeyEvent e) {
			}
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()== KeyEvent.VK_ENTER){
					logInConnection();
				}
			}
			public void keyReleased(KeyEvent e) {
			}
		});
		
		animate[2] = new VoidAnimation(frame, panelStartSelect, panelJoin[1]);
		signUpLogo.addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent e) {
				animate[2].animatePanel(700, 100);
			}
			public void mousePressed(MouseEvent e) {
			}
			public void mouseReleased(MouseEvent e) {
			}
			public void mouseEntered(MouseEvent e) {
				lblSignUp.setForeground(Color.RED);
			}
			public void mouseExited(MouseEvent e) {
				lblSignUp.setForeground(Color.WHITE);
			}
		});
		
		animate[1]= new VoidAnimation(frame, panelStartSelect, panelJoin[0]);
		logInLogo.addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent e) {
				animate[1].animatePanel(500, 100);
			}
			public void mousePressed(MouseEvent e) {
			}
			public void mouseReleased(MouseEvent e) {
			}
			public void mouseEntered(MouseEvent e) {
				lblLogIn.setForeground(Color.RED);
			}
			public void mouseExited(MouseEvent e) {
				lblLogIn.setForeground(Color.WHITE);
			}
		});
		
		animate[3]= new VoidAnimation(frame, panelJoin[0], panelSideBar[0]);
		joinPagelbl[0].addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent e) {
				logInConnection();
			}
			public void mousePressed(MouseEvent e) {
			}
			public void mouseReleased(MouseEvent e) {
			}
			public void mouseEntered(MouseEvent e) {
				joinPagelbl[0].setForeground(Color.RED);
			}
			public void mouseExited(MouseEvent e) {
				joinPagelbl[0].setForeground(Color.WHITE);
			}
		});
		
		scrollPane.setViewportView(table);
		
		txtSearch.addKeyListener(new KeyListener(){
			public void keyTyped(KeyEvent e) {
			}
			public void keyPressed(KeyEvent e) {
			}
			public void keyReleased(KeyEvent e) {
				table.tableSearch(comboBox[0].getSelectedIndex(), txtSearch.getText());
			}
		});	
	}
	
	
	private void logInConnection(){
		conA = new GetSQLConnection();
		if(conA.setConnection(txtUserName[0].getText(), passwordLogIn[0].getText())){
			lblWarning[0].setText("");
			animate[3].animatePanel(1000, 100);
			animate[4]= new VoidAnimation(frame, null, panelMenu[1]);
			animate[4].animatePanel(1000, 100);
			currentPanel=1;
		}else{
			lblWarning[0].setText("wrong username or password!");
		}
		if(conA.isConnected()){
			table.setModel(new DefaultTableModel(conA.getAllTableData(), conA.getAllColumnNames()));
			comboBox[0].setModel(new DefaultComboBoxModel(conA.getAllColumnNames()));
			graphBox.setXYaxis(conA.refreshMonthData());
			pieChartBox.setPieChart(conA.refreshMonthData());
			overviewBox.setData(graphBox.getThisMonthIncome(), 15);
			table.getModel().addTableModelListener(new TableModelListener(){
			public void tableChanged(TableModelEvent e) {
				int selectedRow = table.getSelectedRow(), selectedColumn = table.getSelectedColumn();
				if(table.isEditing()){
					conA.updateDataInTable(table.getValueAt(selectedRow, selectedColumn), selectedRow, selectedColumn);
				}
			}
			});
			table.hideColumn(0);
		}
	}
}
