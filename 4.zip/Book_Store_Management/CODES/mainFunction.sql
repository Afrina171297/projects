set serveroutput on;

begin

/*dbms_output.put_line('This month total income in Dhaka: '|| thisMonthIncomeDhaka);
dbms_output.put_line('This month total income in Dhaka: '|| thisMonthIncomeKhulna);
dbms_output.put_line('This month total income in Dhaka: '|| thisMonthIncomeAll);

showTopSellingBooksDhaka;
showTopSellingBooksKhulna;
showTopSellingBooksAll;

showTopAuthorsDhaka;
showTopAuthorsKhulna;
showTopAuthorsAll;

customerBoughtBooksDhaka(2);
customerBoughtBooksKhulna(2);
customerBoughtBooksAll(2);

dbms_output.put_line('This month total copy sale : '|| thisMonthTotalCopySaleDhaka);
dbms_output.put_line('This month total copy sale : '|| thisMonthTotalCopySaleKhulna);
dbms_output.put_line('This month total copy sale : '|| thisMonthTotalCopySaleAll);

dbms_output.put_line('Day''s total income in Dhaka: '|| dayIncomeDhaka('7-jul-2018'));
dbms_output.put_line('Day''s total income in Khulna: '|| dayIncomeKhulna('7-jul-2018'));
dbms_output.put_line('Day''s total income: '|| dayIncomeAll('7-jul-2018'));

insertOrderDhaka(11, 10, '8-oct-2018', 3, 2);

updateCustomerDhaka(5, 'Tom Hardy', 'th@gmail.com', '231', 'Mirpur', 'Dhaka', '23');


proofAssociative;*/
proofCommutative;

end;
/