set serveroutput on;

begin

insertDataSiteDhaka;
insertDataSiteKhulna;

end;
/