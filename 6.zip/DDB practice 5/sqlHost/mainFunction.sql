set serveroutput on;

begin

dbms_output.put_line('This month total income in Dhaka: '|| thisMonthIncomeDhaka);
dbms_output.put_line('This month total income in Dhaka: '|| thisMonthIncomeKhulna);
dbms_output.put_line('This month total income in Dhaka: '|| thisMonthIncomeAll);

showTopSellingBooksDhaka;
showTopSellingBooksKhulna;
showTopSellingBooksAll;

showTopAuthorsDhaka;
showTopAuthorsKhulna;
showTopAuthorsAll;

customerBoughtBooksDhaka(2);
customerBoughtBooksKhulna(2);
customerBoughtBooksAll(2);

dbms_output.put_line('This month total copy sale : '|| thisMonthTotalCopySaleDhaka);
dbms_output.put_line('This month total copy sale : '|| thisMonthTotalCopySaleKhulna);
dbms_output.put_line('This month total copy sale : '|| thisMonthTotalCopySaleAll);

dbms_output.put_line('Day''s total income in Dhaka: '|| dayIncomeDhaka('7-jul-2018'));
dbms_output.put_line('Day''s total income in Dhaka: '|| dayIncomeKhulna('7-jul-2018'));
dbms_output.put_line('Day''s total income in Dhaka: '|| dayIncomeAll('7-jul-2018'));

end;
/