/* R JN (S JN T) -> (R JN S) JN T */

CREATE OR REPLACE PROCEDURE proofCommutative IS

cursor t1 is select * from order_details@site_link_dhaka 
	inner join (select * from orders@site_link_dhaka inner join customers@site_link_dhaka on customers.cust_num = orders.cust_num) cus_ord on cus_ord.order_num = order_details.order_num;
cursor t2 is (select * from order_details@site_link_dhaka inner join orders@site_link_dhaka on order_details.order_num = orders.order_num) ord_ordd 
	inner join customers@site_link_dhaka on customers.cust_num = ord_ordd.cust_num;

var_t1 t1%ROWTYPE;
var_t2 t2%ROWTYPE;

BEGIN

dbms_output.put_line( chr(9) );

open t1;

  loop
    fetch t1 into var_t1;
    exit when t1%notfound;

    dbms_output.put_line('Customer = ' || var_t1.cust_name || ' Book = ' || var_t1.book_title || ' Order Date = ' || var_t1.order_date);
  end loop;

close t1;

open t2;

  loop
    fetch t2 into var_t2;
    exit when t2%notfound;

    dbms_output.put_line('Customer = ' || var_t2.cust_name || ' Book = ' || var_t2.book_title || ' Order Date = ' || var_t2.order_date);
  end loop;

close t2;

END;
/