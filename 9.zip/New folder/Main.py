import PIL
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap
from math import radians, sin, cos, acos
from operator import itemgetter

pd.set_option('display.expand_frame_repr', False)

m = Basemap(llcrnrlon=88.0, llcrnrlat=21.0, urcrnrlon=93.0, urcrnrlat=27.0, resolution='i', projection='mill', lat_0=23.45, lon_0=90.24)
m.drawcoastlines()
m.drawmapboundary()
m.drawstates()
m.drawcountries()
m.fillcontinents(color = '#333333')

def latlongdist(lat1, lon1, lat2, lon2):
    slat = radians(lat1)
    slon = radians(lon1)
    elat = radians(lat2)
    elon = radians(lon2)
    d = 6371.01 * acos(sin(slat)*sin(elat) + cos(slat)*cos(elat)*cos(slon - elon))
    return d

df = pd.read_csv('dataset/completeDataset.csv')
df.drop(df.columns[[4, 5, 6, 7, 8]], axis=1, inplace=True)
df = df.dropna()
df.columns = ['id', 'Bus Stand', 'Lat', 'Long']

austLon = 90.24
austLat = 23.43
austX, austY = m(austLon, austLat)
m.plot(austX, austY, 'ro', markersize=1)

for index, row in df.iterrows():
    x, y = m(row['Long'], row['Lat'])
    m.plot(x, y, 'bo', markersize=0.05)

busLon = df['Long'].values
busLat = df['Lat'].values

D = df[['Lat', 'Long']].values

austDist = [[index, latlongdist(austLat, austLon, row[0], row[1])] for index, row in enumerate(D)]
austDist.sort(key=itemgetter(1))
print(austDist)





x, y = m(busLon, busLat)
m.plot(x, y, marker=None, color='m', linewidth=0.5)




plt.show()


df = pd.read_csv('dataset/completeDataset.csv')
df.drop(df.columns[[1, 2, 3, 4]], axis=1, inplace=True)
df = df.dropna()
df.columns = ['id', 'Bank Name', 'Home Location', 'Lat', 'Long']

percDfAust = pd.DataFrame({'Count': df[['id', 'Bank Name']].groupby('Bank Name').size(), 'Percentage': df[['id', 'Bank Name']].groupby('Bank Name').size()*100 / len(df)})
print(percDfAust.sort_values('Percentage', ascending=False))

fig, axes = plt.subplots(nrows=2, ncols=1, figsize=(15, 15))
percDfAust['Count'].plot(ax=axes[0], kind='bar', color=(1.0, 0.64, 0.007, 1.0))
percDfAust['Percentage'].plot(ax=axes[1], kind='bar', color=(0.18, 0.2, 0.25, 1.0))
plt.show()

percDfAll = pd.DataFrame({'Count': df[['id', 'Bank Name', 'Home Location']].groupby(['Bank Name', 'Home Location']).size(), 'Percentage': df[['id', 'Bank Name', 'Home Location']].groupby(['Bank Name', 'Home Location']).size()*100 / df[['id', 'Bank Name', 'Home Location']].groupby(['Bank Name']).size()})
print(percDfAll)

unstackedPercDfAll = percDfAll['Count'].unstack()
unstackedPercDfAll.fillna(0).plot(kind='bar', figsize=(30, 15))
plt.show()

